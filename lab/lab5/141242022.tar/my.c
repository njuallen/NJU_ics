#include <stdio.h>
#include <string.h>

//TODO: Define your global data variables here

void challenge(char* str, int n)
{
	char result[] = "\002\001#\021\027/,\017\026\021\064\017"; 
	strcpy(str, result);
	return;
}
